package util

//Add 函数名必须大写开头，才能跨包引用
func Add(a int, b int) int {
	return a + b
}
