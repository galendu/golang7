package main

var (
	name = "zcy"
	Sex  = "male"
)
